/*

	RITensor template, v 0.31
	Copyright Fredrik Sandin (2010), fredrik.sandin@gmail.com
	
    Original implementation of the N-way random indexing algorithm
    used for calculations in the first published manuscript and paper.
*/

#ifndef RITENSOR_H
#define RITENSOR_H

#include <assert.h>

//
// Mersenne Twister random number generator.
// It is unclear how performance depends on the
// quality of random numbers, using this for now.
#include "mtrand.h"

//
// Macros from www.fefe.de/intof.html
#define __HALF_MAX_SIGNED(type) ((type)1 << (sizeof(type)*8-2))
#define __MAX_SIGNED(type) (__HALF_MAX_SIGNED(type) - 1 + __HALF_MAX_SIGNED(type))
#define __MIN_SIGNED(type) (-1 - __MAX_SIGNED(type))
#define __MIN(type) ((type)-1 < 1?__MIN_SIGNED(type):(type)0)
#define __MAX(type) ((type)~__MIN(type))

//
// Used for file I/O only
#include <string.h>
#include <iostream>

/*!
	N-dimensional random-index tensor (N>=1)
	
	This template provides an interface to an N-dimensional tensor
	with random indeces. It can be used as base class when defining
	application-specific tensors. It is based on a probabilistic and
	approximate incremental method to encode large non-sparse and
	sparse tensors. For more information, see F. Sandin & B. Emruli, ...
	
	Observe that N=1 is a special case where the state tensor is two
	dimensional (matrix) but random indeces are used for rows only,
	while ordinary explicit indeces are used for columns. In other
	words, each column represents a vector (1D) that is addressed
	with random indeces. This is the form of random indexing known
	from word-space models (see overview by Magnus Sahlgren @ SICS).
	
	\tparam TState State data type. Must be a signed integer datatype.
	               Choose wisely to reduce memory size and avoid state
	               saturation. Must not have more bits than TNumber,
	               because this breaks saturation logic.
	\tparam TIndex Random index data type. Should be an unsigned
	               integer datatype. Maximum value must be greater
	               than the maximum size of the state tensor.
	               Choose a small data type to reduce memory use
	               (when many random index vectors are defined).
	\tparam TNumber Number data type. Must be an unsigned integer
	                data type. Maximum value must be greater than
	                the total number of states and the maximum
	                number of random index vectors used. Typically
	                an uint32 will work fine. Does not affect the
	                memory footprint significantly.
*/
template <class TState, class TIndex, class TNumber> class RITensor {
public:

	//! Constructs an N-dimensional random-index tensor
	RITensor(TNumber size[], TNumber risize[], TNumber N);
	
	//! Construct and initialize object from stream (load)
	RITensor(std::istream& in);
	
	//! Destructor handles memory release
	virtual ~RITensor();
	
	//! Get order of tensor / number of dimensions
	TNumber order(void);
	
	//! Get size of state tensor in a specific dimension
	TNumber stateSize(TNumber dim);
	
	//! Get number of indeces (index range) in a specific dimension
	TNumber indexCount(TNumber dim);

	//! Get size of random-index vectors in a specific dimension
	TNumber indexSize(TNumber dim);
	
	//! Add random-index vectors (increases index range)
	void addIndeces(TNumber dim, TNumber count);
		
	//! Determines saturation level of state tensor
	TNumber saturation(void);
	
	//! Add weight to tensor component
	void encode(TNumber indeces[], TState weight=1, bool reset=false);

	//! Decode weight of tensor component
	void decode(TNumber indeces[], TNumber &score, TState &sgn);
	
	//! Find significant tensor components (decoding)
	void find(TNumber dims[], TNumber indeces[],
		TNumber p_result[], TNumber p_score[],
		TNumber n_result[], TNumber n_score[],
		TNumber count);

	//! Add weight to count randomly chosen tensor components
	void randomize(TState weight, TNumber count);
	
	//! Add random weights in the range [low, high] to all tensor components
	void randinit(TState low, TState high);
	
	//! Write object to stream (save)
	void write(std::ostream& out);

protected:

	//! Helper function used to create random-index vectors
	void createIndexVectors(TNumber dim, TNumber count, TIndex *dest);
	
	/*!
		This function must be called from the destructor of a derived
		class iff the memory allocation functions (below) are overridden.
	*/
	void clearIndex(void);
	
	//! Memory allocation function, defaults to malloc()
	virtual void *__malloc(TNumber size);

	//! Memory re-allocation function, defaults to realloc()
	virtual void *__realloc(void *ptr, TNumber size);

	//! Memory release function, defaults to free()
	virtual void __free(void *ptr);

	TNumber N_;
	
	TIndex **index_;
	TNumber *risize_, *ricount_;
	TNumber rilen_, *riprod_;
	
	TState *states_;
	TState minstate_, maxstate_;
	TNumber *stsize_, stlen_;
	
	TNumber saturation_;
	TNumber minnumber_, maxnumber_;
	
	MTRand mtrand_;
};


/*!
	Observe that N=1 is a special case where the state tensor is
	two dimensional but random indeces are used for rows only,
	while ordinary explicit indeces are used for columns. This
	implies that the number of valid column indeces is fixed
	after construction of a N=1 tensor, while row indeces
	can be allocated dynamically.

	\param size Array specifying the size of the state tensor (length N).
	\param risize Array specifying the lengths of the random index vectors for each dimension (length N).
	\param N Order of tensor, e.g., 2 for an ordinary matrix (N>=1).
*/
template <class TState, class TIndex, class TNumber>
RITensor<TState,TIndex,TNumber>::RITensor(TNumber size[], TNumber risize[], TNumber N) {
	
	assert(N > 0);
	assert(__MIN(TIndex) == 0);  // Don't waste space
	assert(__MIN(TState) < 0);   // Must be signed
	assert(__MIN(TNumber) == 0); // Must be unsigned
	
	N_ = N;
	stlen_ = 1;
	rilen_ = 1;

	stsize_ = new TNumber[(N>1)?N:N+1]; // 1D special case
	risize_ = new TNumber[N];
	ricount_ = new TNumber[N];
	riprod_ = new TNumber[N];
	index_ = new TIndex*[N];

	TNumber i,j;
	for(i=0; i<N; i++) {

		// Index size must be even, see createIndexVectors()
		assert(!(risize[i] & 0x1));
		
		// Length of index vector must be smaller than the range of the
		// corresponding dimension in the state tensor, otherwise unique
		// indeces cannot be found and createIndexVectors() will end up
		// in an infinte loop.
		assert(risize[i] <= size[i]);
		
		// Assert capacity of index data type
		assert(size[i] <= __MAX(TIndex));

		stlen_ *= size[i];
		stsize_[i] = size[i];
		index_[i] = 0; // NULL
		ricount_[i] = 0;
		rilen_ *= risize[i];
		risize_[i] = risize[i];
	}
	if(N==1) { // 1D special case
		assert(size[1] <= __MAX(TIndex));
		stlen_ *= size[1];
		stsize_[1] = size[1];
	}
	
	// Assert capacity of number data type
	assert(stlen_ <= __MAX(TNumber));

	/////////////////////////////////////////////////////////////////
	// Index transformation rule, {ui} <--> {i0,i1,i2,...}, is
	// ui = i0 + risize[0]*(i1 + risize[1]*(i2 + risize[2]*(...)))
	// and 0 <= i0 < risize[0] etc. Define riprod[] such that
	//
	// i[n]   = ui / riprod[n];   ui -= i[n]*riprod[n];
	// i[n-1] = ui / riprod[n-1]; ui -= i[n-1]*riprod[n-1];
	// i[n-2] = ui / riproc[n-2]; ui -= i[n-2]*riprod[n-2];
	// ...
	// Caches might prefer forward iteration, but that reverses
	// coordinate order. Keeping things readable for now.
	/////////////////////////////////////////////////////////////////
	for(i=0; i<N; i++) {
		riprod_[i] = 1;
		for(j=0; j<i; j++) {
			riprod_[i] *= risize_[j];
		}
	}

	states_ = new TState[stlen_];
	for(i=0; i<stlen_; i++) states_[i]=0;
	minstate_ = __MIN(TState);
	maxstate_ = __MAX(TState);
	minnumber_ = __MIN(TNumber);
	maxnumber_ = __MAX(TNumber);
	saturation_ = 0;
}

/*!
	\todo Add support for byte order invariance (big/little endian) and make I/O fool proof.
*/
template <class TState, class TIndex, class TNumber>
void RITensor<TState,TIndex,TNumber>::write(std::ostream& out) {
	TNumber i;
	out	<< "RITensor_001{"
		<< (char)sizeof(TState)
		<< (char)sizeof(TIndex)
		<< (char)sizeof(TNumber);
	out.write((char*)&N_, sizeof(N_));
	out.write((char*)&saturation_, sizeof(saturation_));
	out.write((char*)risize_,N_*sizeof(risize_[0]));
	out.write((char*)ricount_,N_*sizeof(ricount_[0]));
	for(i=0; i<N_; i++) {
		TIndex *p = index_[i];
		TNumber count = risize_[i]*ricount_[i];
		out.write((char*)p,count*sizeof(p[0]));
	}
	TNumber count = (N_>1) ? N_:N_+1; // 1D special case
	out.write((char*)stsize_,count*sizeof(stsize_[0]));
	out.write((char*)states_,stlen_*sizeof(states_[0]));
	out << "}"; // Terminating bracket
}

/*!
	\todo Make input robust towards corrupt files and
	throw exceptions in case of errors. Keeping things
	simple for now.
*/
template <class TState, class TIndex, class TNumber>
RITensor<TState,TIndex,TNumber>::RITensor(std::istream& in) {

	char t1,t2,t3;
	char vstr[] = "RITensor_001{";
	char rdbuf[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	
	// Check file header
	in.read(rdbuf,sizeof(vstr)-1);
	in >> t1 >> t2 >> t3;
	if(	strcmp(rdbuf,vstr)!=0 ||
		t1!=sizeof(TState)    ||
		t2!=sizeof(TIndex)      ||
		t3!=sizeof(TNumber)) {

		// Note:
		// This is a typical failure, because data sizes are different on
		// different systems. In particular users are in for surprises when
		// using both 32 and 64 bit platforms for calculation / analysis.

		N_=0;
		index_=0;
		risize_=0;
		ricount_=0;
		rilen_=0;
		riprod_=0;
		states_=0;
		stsize_=0;
		stlen_=0;
		saturation_=0;

		return;
	}	

	in.read((char*)&N_, sizeof(N_));
	in.read((char*)&saturation_, sizeof(saturation_));

	TNumber N = (N_>1) ? N_:N_+1; // 1D special case
	stlen_ = 1;
	rilen_ = 1;
	stsize_ = new TNumber[N];
	risize_ = new TNumber[N_];
	ricount_ = new TNumber[N_];
	riprod_ = new TNumber[N_];
	index_ = new TIndex*[N_];
	
	in.read((char*)risize_,N_*sizeof(risize_[0]));
	in.read((char*)ricount_,N_*sizeof(ricount_[0]));
	TNumber i,j;
	for(i=0; i<N_; i++) {
		rilen_ *= risize_[i];
		TNumber count = risize_[i]*ricount_[i];
		index_[i] = (TIndex*)__malloc(count*sizeof(TIndex));
		in.read((char*)index_[i], count*sizeof(TIndex));
	}

	in.read((char*)stsize_, N*sizeof(stsize_[0]));
	for(i=0; i<N; i++) stlen_ *= stsize_[i];
	states_ = new TState[stlen_];
	in.read((char*)states_,stlen_*sizeof(states_[0]));

	in >> rdbuf[0]; // Should be '}'

	// Nothing more to read from file
	/////////////////////////////////
	
	for(i=0; i<N_; i++) {
		riprod_[i] = 1;
		for(j=0; j<i; j++) {
			riprod_[i] *= risize_[j];
		}
	}

	minstate_ = __MIN(TState);
	maxstate_ = __MAX(TState);
	minnumber_ = __MIN(TNumber);
	maxnumber_ = __MAX(TNumber);
}

template <class TState, class TIndex, class TNumber>
RITensor<TState,TIndex,TNumber>::~RITensor() {

	clearIndex();
	if(N_>0) {
		delete[] states_;
		delete[] stsize_;
		delete[] risize_;
		delete[] riprod_;
		delete[] ricount_;
		delete[] index_;
	}
}

template <class TState, class TIndex, class TNumber>
void RITensor<TState,TIndex,TNumber>::clearIndex(void) {
	for(TNumber i=0; i<N_; i++) {
		if(index_[i] != 0) {
			__free(index_[i]);
			index_[i]=0;
		}
	}
}

template <class TState, class TIndex, class TNumber>
TNumber RITensor<TState,TIndex,TNumber>::order(void) {
	return N_;
}

template <class TState, class TIndex, class TNumber>
TNumber RITensor<TState,TIndex,TNumber>::stateSize(TNumber dim) {
	assert(dim < (N_>1?N_:N_+1));
	return stsize_[dim];
}

template <class TState, class TIndex, class TNumber>
TNumber RITensor<TState,TIndex,TNumber>::indexCount(TNumber dim) {
	assert(dim < N_);
	return ricount_[dim];
}

template <class TState, class TIndex, class TNumber>
TNumber RITensor<TState,TIndex,TNumber>::indexSize(TNumber dim) {
	assert(dim < N_);
	return risize_[dim];
}

/*!
	Add index vectors for a particular dimension.
	Users may add more index vectors than presently needed to
	avoid excessive memory reallocation. Each vector requires
	sizeof(TIndex)*risize[dim] bytes of memory, see the
	constructor for definitions.

	\param dim Dimension index in [0,(N-1)]
	\param count Number of index vectors to add
*/
template <class TState, class TIndex, class TNumber>
void RITensor<TState,TIndex,TNumber>::addIndeces(TNumber dim, TNumber count) {
	
	// Allocate space for new vectors
	assert(dim < N_);
	TNumber offset=0, size=count*risize_[dim]*sizeof(TIndex);
	if(index_[dim] == 0) {
		index_[dim] = (TIndex*)__malloc(size);
		ricount_[dim] = count;
	} else {
		offset = ricount_[dim];
		size += offset*risize_[dim]*sizeof(TIndex);
		index_[dim] = (TIndex*)__realloc(index_[dim], size);
		ricount_[dim] += count;	
	}
	// Create random indeces
	createIndexVectors(dim, count, &index_[dim][risize_[dim]*offset]);
}

/*!
	The tensor state is made of TState variables. When data
	is encoded, product(risize[i]) states are updated, e.g.,
	100 states for a 2D tensor with index vectors of length 10.
	State variables have small size to reduce memory needs.
	Under-/overflow can therefore occurr and each time a
	state-change fails for this reason the saturation level
	will increase by the magnitude of the under-/overflow.
	Zero saturation means that no state changes have failed.

	\return Saturation level of tensor states, see description.
*/
template <class TState, class TIndex, class TNumber>
TNumber RITensor<TState,TIndex,TNumber>::saturation(void) {
	return saturation_;
}

/*!
	Add weight to tensor component, possibly resetting it
	to zero before addition. This is a lossy operation,
	because the number of tensor states typically is
	lower than the indexable size of the tensor.

	Observe that N=1 is a special case where the state tensor is
	two-dimensional but random indeces are used for rows only,
	while ordinary explicit indeces are used for columns.
	
	\param indeces Indeces for each dimension of the tensor.
	            Observe that N=1 tensors require 2 indeces,
				one for the random-indexed row and one for the
				explicit column index (of the state matrix).
	\param weight Weight that determines how much the
	              tensor states are updated (default 1).
				  Can be negative.
	\param reset If set to true the affected tensor states
	             will be set to zero before encoding. This means
				 that statistics is lost for other index
				 combinations as well (use with special care,
				 false by default).
*/
template <class TState, class TIndex, class TNumber>
void RITensor<TState,TIndex,TNumber>::encode(TNumber indeces[],
 TState weight, bool reset) {
	
	TNumber d;
	for(d=0; d<N_; d++) assert(indeces[d] < ricount_[d]);
	if(N_==1) assert(indeces[1]<stsize_[1]); // 1D special case

	if(weight==0) return; // Nothing to do
	TState absweight = (weight < 0) ? -weight : weight;

	// Unrolled N-dimensional loop over random indeces
	TNumber *indi = new TNumber[N_];
	TNumber *statei = indi;
	for(TNumber ui=0; ui<rilen_; ui++) {
	
		// Calculate ri indeces, overall sign, and state index
		d = N_;
		TState wsign=(weight<0) ? -1 : 1;
		TNumber temp=ui, stateindex=0;
		do{ d--;

			// Calculate ri index (see constructor for info)
			indi[d] = temp/riprod_[d];
			temp -= indi[d]*riprod_[d];

			// Signs are hardcoded, first (last) half of ri vector
			// corresponds to positive (negative) weights
			if(indi[d] >= (risize_[d]>>1)) wsign = -wsign;

			// Fetch state index from table (***** overwrites indi[d] *****)
			statei[d] = index_[d][ risize_[d]*indeces[d] + indi[d] ];
			
			// Calculate linear state index using the same
			// transformation rule as for ri indeces
			// i = i0 + stsize[0]*(i1 + stsize[1]*(i2 + stsize[2]*(...)))
			stateindex = statei[d] + stsize_[d]*stateindex;

		} while(d > 0); // note: d may be unsigned!
		
		// 1D special case
		if(N_==1) {
			stateindex += stsize_[0]*indeces[1];
		}
		
		// Update matrix state and saturation level
		if(reset) {
		
			states_[stateindex] = weight;
		
		} else if(wsign==1) {
			
			if(states_[stateindex] < 0) { // No overflow
				states_[stateindex] += absweight;
			} else {	
				TNumber state = states_[stateindex] + absweight;
				if(state > maxstate_) {
					saturation_ += (state - maxstate_);
					states_[stateindex] = maxstate_;
				} else {
					states_[stateindex] += absweight;
				}
			}
		
		} else { // sign == -
			
			if(states_[stateindex] > 0) { // No underflow
				states_[stateindex] -= absweight;
			} else {	
				TNumber magn = -states_[stateindex] + absweight;
				if(magn > -minstate_) {
					saturation_ += (magn + minstate_);
					states_[stateindex] = minstate_;
				} else {
					states_[stateindex] -= absweight;
				}
			}
		}
	}
	delete[] indi;
}

/*!
	Decode a single tensor component, see also find().

	\param indeces Indeces of component
	\param score Absolute score of component, which is the accumulated
	             weight of the corresponding states * prod(risize[]).
			     For example, a 2D tensor with RI vectors of length
			     20 would have prod(risize[]) = 20*20 = 400. A score
			     of 400 corresponds to an accumulated weight of 1.
			     In general, weight ~ score / prod(risize[]).
	\param sgn The sign of the score
*/
template <class TState, class TIndex, class TNumber>
void RITensor<TState,TIndex,TNumber>::decode(TNumber indeces[],
 TNumber &score, TState &sgn) {

	TNumber d;
	for(d=0; d<N_; d++) assert(indeces[d]<ricount_[d]);
	if(N_==1) // 1D special case
		assert(indeces[1]<stsize_[1]);

	// Unrolled N-dimensional loop over random indeces
	TNumber sumpos=0,sumneg=0;
	TNumber *indi = new TNumber[N_];
	TNumber *statei = indi;
	for(TNumber ui=0; ui<rilen_; ui++) {

		// Calculate ri indeces, overall sign, and state index
		d = N_;
		TState wsign=1;
		TNumber t=ui, stateindex=0;
		do{ d--;

			// Calculate ri index (see constructor for info)
			indi[d] = t/riprod_[d];
			t -= indi[d]*riprod_[d];

			// Signs are hardcoded, first (last) half of ri vector
			// corresponds to positive (negative) weights
			if(indi[d] >= (risize_[d]>>1)) wsign = -wsign;

			// Fetch state index from table (***** overwrites indi[d] *****)
			statei[d] = index_[d][ risize_[d]*indeces[d] + indi[d] ];
		
			// Calculate linear state index using the same
			// transformation rule as for ri indeces
			// i = i0 + stsize[0]*(i1 + stsize[1]*(i2 + stsize[2]*(...)))
			stateindex = statei[d] + stsize_[d]*stateindex;

		} while(d > 0); // note: d may be unsigned!

		// 1D special case
		if(N_==1) {
			stateindex += stsize_[0]*indeces[1];
		}
		
		// Add matrix state to overall score
		if(wsign==1) {

			if(states_[stateindex] > 0) sumpos += states_[stateindex];
			if(states_[stateindex] < 0) sumneg -= states_[stateindex];

		} else {

			if(states_[stateindex] < 0) sumpos -= states_[stateindex];
			if(states_[stateindex] > 0) sumneg += states_[stateindex];
		}
	}

	// Update result if score is sufficient
	if(sumpos >= sumneg) {
		sgn = 1;
		score = sumpos - sumneg;
	} else {
		sgn = -1;
		score = sumneg - sumpos;
	}
	delete[] indi;
}


/*!
	Find (decode) indeces of significant components given N-1 indeces.
	This operation is analogous to the following operation on ordinary
	tensors: find x so that abs(tensor(i1, i2, i3, ..., x, ..., iN)) is
	maximal for given indeces i#. In contrast to ordinary tensors the
	result is approximate. A top-list of indeces corresponding to the most
	significant elements is returned. The accuracy of this list depends
	on several things, including parameters, saturation and data
	characteristics. The most significant elements (on a non-local scale)
	are often accurately represented, while "spurious" memories appear
	at lower ranking. The result is divided into two parts, one with
	positive scores and one with negative scores. A high negative score
	is an "anti-match", which could be important for classification
	applications where the RI tensor is used for dimension reduction.

	Observe that N=1 is a special case where the state tensor is
	two-dimensional, but random indeces are used for rows only and
	ordinary explicit indeces are used for columns. In this case the
	search is performed for a fixed column index, i.e., dims[]={1}
	and indeces[]={column_index}.
	
	\param dims Array of dimension indeces for the given indeces (length max(1,N-1))
	\param indeces Array of indeces for the given dimensions (length max(1,N-1))
	\param p_result Array of indeces with higest scores (output, length 'count').
	\param p_score Array of scores for p_result, i.e., the averages of the
	             accumulated weights * prod(risize[]) (output, length 'count').
				 See decode() for information on how to normalize scores.
	\param n_result Array of indeces with lowest negative scores (output, length 'count').
	\param n_score Array of scores for n_result, i.e., the averages of the
	             accumulated weights * prod(risize[]) (output, length 'count').
				 These scores are negative, but the sign is removed since TNumber
				 is assumed to be an unsigned data type.
				 See decode() for information on how to normalize scores.
	\param count Number of results to return, i.e., length of top-lists.
	             Caller must allocate space for scores and results.

*/
template <class TState, class TIndex, class TNumber>
void RITensor<TState,TIndex,TNumber>::find(TNumber dims[], TNumber indeces[],
	TNumber p_result[], TNumber p_score[],
	TNumber n_result[], TNumber n_score[],
	TNumber count) {
	
	TNumber d;
	for(d=0; d<N_-1; d++) assert(indeces[d] < ricount_[d]);
	if(N_==1) { // 1D special case
		assert(indeces[0]<stsize_[1]);
		assert(dims[0]==1);
	}

	// Find complementary dimension
	TNumber cd=0, *temp = new TNumber[(N_>1)?N_:N_+1];
	if(N_>1) {
		for(d=0; d<N_; d++) temp[d]=0;
		for(d=0; d<N_-1; d++) temp[dims[d]]=1;
		for(d=0; d<N_; d++) if(temp[d]==0) cd=d;
	} /*else { // 1D special case
		cd = 0;
	}*/

	assert(count <= ricount_[cd]);
	
	// Assemble list of indeces
	if(N_==1) { // 1D special case
		temp[1] = indeces[0];
	} else {
		for(d=0; d<N_-1; d++) temp[dims[d]]=indeces[d];
	}
	indeces = temp;
	
	// Reset result
	TNumber p_count=0, n_count=0;
	for(d=0; d<count; d++) {
		p_result[d] = maxnumber_;
		p_score[d] = minnumber_;
		n_result[d] = maxnumber_;
		n_score[d] = minnumber_;
	}

	// Loop over complementary indeces to find top matches
	TNumber *indi = new TNumber[N_];
	for(TNumber ck=0; ck<ricount_[cd]; ck++) {
		
		// Set complementary index
		indeces[cd] = ck;

		// Unrolled N-dimensional loop over given indeces
		TNumber sumpos=0,sumneg=0;
		TNumber *statei = indi;
		for(TNumber ui=0; ui<rilen_; ui++) {
	
			// Calculate ri indeces, overall sign, and state index
			d = N_;
			TState wsign=1;
			TNumber t=ui, stateindex=0;
			do{ d--;

				// Calculate ri index (see constructor for info)
				indi[d] = t/riprod_[d];
				t -= indi[d]*riprod_[d];

				// Signs are hardcoded, first (last) half of ri vector
				// corresponds to positive (negative) weights
				if(indi[d] >= (risize_[d]>>1)) wsign = -wsign;

				// Fetch state index from table (***** overwrites indi[d] *****)
				statei[d] = index_[d][ risize_[d]*indeces[d] + indi[d] ];
			
				// Calculate linear state index using the same
				// transformation rule as for ri indeces
				// i = i0 + stsize[0]*(i1 + stsize[1]*(i2 + stsize[2]*(...)))
				stateindex = statei[d] + stsize_[d]*stateindex;

			} while(d > 0); // note: d may be unsigned!

			// 1D special case
			if(N_==1) {
				stateindex += stsize_[0]*indeces[1];
			}
			
			// Add matrix state to overall score
			if(wsign==1) {

				if(states_[stateindex] > 0) sumpos += states_[stateindex];
				if(states_[stateindex] < 0) sumneg -= states_[stateindex];

			} else {	

				if(states_[stateindex] < 0) sumpos -= states_[stateindex];
				if(states_[stateindex] > 0) sumneg += states_[stateindex];
			}
		}

		// Update result if score is sufficient
		TNumber s, *result, *score, *rcount;
		if(sumpos >= sumneg) {
			s = sumpos - sumneg;
			result = p_result;
			score = p_score;
			rcount = &p_count;
		} else { // (sumpos < sumneg)
			s = sumneg - sumpos;
			result = n_result;
			score = n_score;
			rcount = &n_count;
		}
		for(d=0; d<count; d++) {
			if(s >= score[d]) {
				
				// Result found
				(*rcount)++;
				
				// Shift existing results right
				TNumber i = ((*rcount)<count) ? (*rcount) : count;
				while(--i > d) {
					score[i] = score[i-1];
					result[i] = result[i-1];
				}
				
				// Store it and continue the search
				score[d] = s;
				result[d] = ck;
				break;
			}
		}
	}
	
	delete[] indeces; // pointer was updated
	delete[] indi;
}

/*!
	\param weight Weight to be added to the randomly chosen tensor components
	\param count Number of randomly chosen components that should be updated (repetitions possible)
*/
template <class TState, class TIndex, class TNumber>
void RITensor<TState,TIndex,TNumber>::randomize(TState weight, TNumber count) {
	TNumber *indeces = new TNumber[(N_>1)?N_:N_+1];
	for(TNumber i=0; i<count; i++) {
		for(TNumber j=0; j<N_; j++) {
			indeces[j] = mtrand_.randInt(ricount_[j]-1);
		}
		if(N_==1) { // 1D special case
			indeces[1] = mtrand_.randInt(stsize_[1]-1);
		}
		encode(indeces,weight);
	}
	delete[] indeces;
}

/*!
	\param low Lower limit of randomly generated weights
	\param high Upper limit of randomly generated weights
*/
template <class TState, class TIndex, class TNumber>
void RITensor<TState,TIndex,TNumber>::randinit(TState low, TState high) {
	assert(minstate_ <= low);
	assert(maxstate_ >= high);
	assert(low <= high);
	TNumber len=1,i,j;
	TNumber *indeces = new TNumber[(N_>1)?N_:N_+1]; // 1D special case
	for(i=0; i<N_; i++) {
		len *= indexCount(i);
		indeces[i] = 0;
	}
	if(N_==1) { // 1D special case
		len *= stsize_[1];
		indeces[1] = 0;
	}	
	// Unrolled N-dimensional loop
	for(i=0; i<len; i++) {
		// DEBUG:
		//std::cout << indeces[0] << "\t" << indeces[1] << std::endl;
		TState weight=low;
		if(high != low) {
			weight = low+mtrand_.randInt(high-low);
		}
		encode(indeces,weight);
		for(j=N_; j>0; j--) { // Note: j is unsigned
			TNumber &ind = indeces[j-1];
			ind += 1;
			if(ind == indexCount(j-1)) {
				ind = 0;
				if(N_==1) { // 1D special case
					indeces[1] += 1;
					if(indeces[1]==stsize_[1]) {
						break;
					}
				}
			} else {
				break;
			}
		}
	}
}


/*!
	Create new ri vectors for a particular dimension. The length of
	the vectors are determined by the risize[] argument of the
	constructor. Memory is not (re-)allocted here and member
	variables are not updated. That functionality is factored
	out to the calling function addIndeces().
	
	A convention here is that the first risize[dim]/2 indeces
	of a vector have positive weight, while the remaining indeces
	have negative weight (+++...---...).
	It is essenatial from a statistical point of view that half
	of the index has opposite sign.
	
	The number of possible index vectors is C(matsize,risize),
	where C is a binomial coefficient. For example, with 10 000
	states and a risize of 20 there are C(10000,20) = 4e61
	possible vectors. The probability of a collision is given by
	P(N,K) ~ 1 - exp(-K^2/(2N)), where N is the number of
	possible vectors and K is the number of vectors in use. In
	the example above N = 4e61. The probability of a collision
	would be 1e-10 when 1e26 vectors are used, and practically
	zero for a realistic number of vectors / indeces.
	 
	Increasing the risize has a significant effect on the
	number of possible vectors (combinatorial) and therefore
	reduces the collision probability accordingly, but larger
	vectors also creates a stronger coupling between different
	components. Which risize that is best to use is data
	dependent (details unclear).

	\param dim Dimension index in [0,(N-1)]
	\param count Number of ri vectors to create
	\param dest Destination where vectors are stored,
	            caller must allocate memory
*/
template <class TState, class TIndex, class TNumber>
void RITensor<TState,TIndex,TNumber>::createIndexVectors(TNumber dim,
	TNumber count, TIndex *dest) {
	
	TIndex upper = stsize_[dim]-1;
	TNumber risize = risize_[dim];
	
	// For each vector
	for(TNumber i=0; i<count; i++) {
	
		// Generate random indeces
		TNumber j=0;
		while(j < risize) {
		
			// Generate random number in [0,upper]
			TIndex rnd = mtrand_.randInt(upper);
			
			// Check if number is unique. RI vectors are short by rule (~20),
			// because sparse representations are needed. A linear search is
			// therefore justified. Keeping a sorted list to reduce search
			// complexity would create overhead that likely ruins the effort
			bool exist = false;
			for(TNumber z=0; z<j; z++) {
				if(rnd==dest[z]) {
					exist=true;
					break;
				}
			}
			
			// Add this unique index to the ri vector
			if(!exist) dest[j++] = rnd;
		}
		
		// Advance pointer to next vector
		dest += risize;
	}
}

template <class TState, class TIndex, class TNumber>
void * RITensor<TState,TIndex,TNumber>::__malloc(TNumber size) {
	void *p = malloc(size);
	assert(p>0);
	return p;
}

template <class TState, class TIndex, class TNumber>
void * RITensor<TState,TIndex,TNumber>::__realloc(void *ptr, TNumber size) {
	void *p = realloc(ptr,size);
	assert(p>0); 
	return p;
}

template <class TState, class TIndex, class TNumber>
void RITensor<TState,TIndex,TNumber>::__free(void *ptr) {
	free(ptr);
}

/*

Changelog

v0.3
- Made randinit() compatible with one-way indexing. This special
  case was omitted in the initial implementation.
v0.31
- Updated an assert statement in stateSize() that was incompatible
  with one-way indexing.

*/

#endif // RITENSOR_H
