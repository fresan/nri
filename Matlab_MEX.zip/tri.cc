/*******************************************************************************
 * RITensor Matlab MEX implementation, v 0.31
 *
 * Copyright Fredrik Sandin (2010), fredrik.sandin@gmail.com
 *
 * Original implementation of the N-way random indexing algorithm
 * used for calculations in the first published manuscript and paper.
 *******************************************************************************
 * 
 * Tensor with random index (tri) for Matlab.
 *
 * Note that in MATLAB indeces start at 1 (C++ template uses zero-based indeces)
 *
 * Usage in Matlab:
 * ----------------
 * >> tri('clear')                             % Clear all
 *
 * >> tri('clear', handle)                     % Clear specific RI tensor
 *
 * >> handle = tri('create', stsize, risize)   % Create new RI tensor
 *
 * >> order = tri('order', handle)             % Number of dimensions
 *
 * >> size = tri('statesize', handle, dim)     % Size of state tensor
 *
 * >> tri('indadd', handle, dim, count)        % Add RI indeces
 *
 * >> count = tri('indcount', handle, dim)     % Number of RI indeces defined
 *
 * >> size = tri('indsize', handle, dim)       % Size of RI vectors
 *
 * >> tri('encode', handle, indeces, weight)   % Add weight to tensor component
 *
 * >> score = tri('decode', handle, indeces)   % Decode tensor component
 * 
 * >> sat = tri('saturation', handle)          % Saturation of tensor states
 *
 * >> [p_result,p_score,n_result,n_score]
 * = tri('find', handle, dims, indeces, count) % Find significant tensor components
 *
 * >> tri('randomize', handle, weight, count)  % Add weight to random tensor components
 *
 * >> tri('randinit', handle, low, high)       % Add random weights in [low,high] to all tensor components
 *
 * >> ritable = tri('ritable', handle, dim)    % Export random-index table
 *
 * >> state = tri('state', handle)             % Export state tensor
 *
 * >> tri('save', handle, filename)            % Save RI tensor to file
 *
 * >> handle = tri('load', filename)           % Load RI tensor from file
 *
 *******************************************************************************/
 
#include <new>
#include <mex.h>
#include <string.h>
#include <fstream>

// Overloaded c++ new/delete operators
void* operator new (size_t size) {
	void *p=mxMalloc(size); 
	mexMakeMemoryPersistent(p);
	return p;
}
void* operator new[](size_t size) {
	void *p=mxMalloc(size); 
	mexMakeMemoryPersistent(p);
	return p;
}
void operator delete (void *p) {mxFree(p);}
void operator delete[](void *p) {mxFree(p);}

/*******************************************************************/

#include "tri.h"

typedef signed short TState;
typedef unsigned long TIndex;
typedef unsigned long TNum;

#define T_MATLAB_STATE mxINT16_CLASS

class RIMatlab : public RITensor<TState,TIndex,TNum> {
public:
	RIMatlab(std::istream& in)
		: RITensor<TState,TIndex,TNum>(in) {
		// TState must be consistent with Matlab type mxINT16_CLASS
		assert(sizeof(TState)==2);
	};
	RIMatlab(TNum stsize[], TNum risize[], TNum dims)
		: RITensor<TState,TIndex,TNum>(stsize,risize,dims) {
		// TState must be consistent with Matlab type mxINT16_CLASS
		assert(sizeof(TState)==2);
	};
	~RIMatlab() {
		clearIndex(); // Obligatory, custom memory allocation
	}
	
	// Extract RI table
	mxArray *ri(TNum dim) {
		assert(dim<N_);
		TNum count = ricount_[dim];
		TNum size = risize_[dim];
		TIndex *arr = index_[dim];
		mwSize dims[] = {count, size};
		mxArray *r = mxCreateNumericArray(2, dims, mxDOUBLE_CLASS, mxREAL);
		double *rp = mxGetPr(r);
		for(TNum i=0; i<count; i++) {
			for(TNum j=0; j<size; j++) {
				// Convert row-major to col-major (RI table
				// is row-major for technical reasons).
				rp[j*count+i] = arr[i*size+j]+1; // index from 1
			}
		}
		return r;
	}

	// Extract state
	mxArray *state(void) {
		TNum i, N=(N_>1)?N_:N_+1; // 1D special case
		mwSize *dims = new mwSize[N];
		for(i=0; i<N; i++) dims[i] = stsize_[i];
		mxArray *r = mxCreateNumericArray(N, dims, T_MATLAB_STATE, mxREAL);
		TState *rp = (TState*)mxGetData(r);
		for(i=0; i<stlen_; i++) {
			rp[i] = states_[i];
		}
		delete[] dims;
		return r;
	}
	
protected:
	void *__malloc(TNum size) {
		void *p = mxMalloc(size);
		mexMakeMemoryPersistent(p);
		return p;
	}
	void *__realloc(void *ptr, TNum size) {
		void *p = mxRealloc(ptr,size);
		mexMakeMemoryPersistent(p);
		return p;
	}
	void __free(void *ptr) {mxFree(ptr);}
};

/*******************************************************************/
/* Global state variables                                          */

static TNum g_count=0;
static TNum g_handle=1; // 0 is an invalid handle
static RIMatlab **g_rim=0;

/*******************************************************************/

void reset(void) {
	if(g_count > 0) {
		for(TNum i=0; i<g_count; i++) {
			if(g_rim[i] != 0) {
				delete g_rim[i];
				g_rim[i] = 0;
			}
		}
		g_count = 0;
	}
	if(g_rim != 0) {
		delete[] g_rim;
		g_rim = 0;
	}
	g_handle = 1;
}

/*******************************************************************/

void allocate() {
	if(g_handle > g_count) {
		TNum i;
		const TNum inc=100;
		g_count += inc;
		RIMatlab **temp = new RIMatlab*[g_count];
		temp[0] = 0;
		for(i=1; i<g_handle; i++) temp[i] = g_rim[i];
		for(i=g_handle; i<g_count; i++) temp[i]=0;
		if(g_rim!=0) delete[] g_rim;
		g_rim = temp;
	}
}

/*******************************************************************/

TNum get_handle(int nrhs, const mxArray *prhs[]) {
	if(nrhs<2) {
		mexErrMsgTxt("Expected tensor handle in second argument");
	}
	TNum handle = (TNum)mxGetScalar(prhs[1]);
	if(g_count>handle) {
		if(g_rim[handle]!=0) {
			return handle;
		} else {
			mexErrMsgTxt("Invalid tensor handle");
		}
	}
	mexErrMsgTxt("Invalid tensor handle");
	return 0;
}

/*******************************************************************/

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {

	mexAtExit(&reset);

	char strbuf[1024];
	if(nrhs<1)
		mexErrMsgTxt("Empty argument list not expected");
	if(mxGetString(prhs[0], strbuf, sizeof(strbuf)/sizeof(char))!=0)
		mexErrMsgTxt("Expected first argument to be a command (string)");
	
	if(strcmp("encode", strbuf)==0) {

		if(nrhs==4) {

			TNum ind[20]; // Hardcoded limit, avoid new here

			TNum handle = get_handle(nrhs,prhs);
			TNum dim = g_rim[handle]->order();
			TNum N = dim>1 ? dim : dim+1; // 1D special case
			if(mxGetM(prhs[2])!=1 || mxGetN(prhs[2])!=N) 
				mexErrMsgTxt("Invalid size of index array");
			TState weight = (TState)mxGetScalar(prhs[3]);
			double *kp = mxGetPr(prhs[2]);
			for(TNum i=0; i<N; i++) ind[i]=(TNum)kp[i]-1; // Matlab index start at 1
			g_rim[handle]->encode(ind,weight);
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("decode", strbuf)==0) {

		if(nrhs==3) {

			TNum ind[20]; // Hardcoded limit, avoid new here

			TNum handle = get_handle(nrhs,prhs);
			TNum dim = g_rim[handle]->order();
			TNum N = dim>1 ? dim : dim+1; // 1D special case
			if(mxGetM(prhs[2])!=1 || mxGetN(prhs[2])!=N) 
				mexErrMsgTxt("Invalid size of index array");
			double *kp = mxGetPr(prhs[2]);
			for(TNum i=0; i<N; i++) ind[i]=(TNum)kp[i]-1; // Matlab index start at 1
			TNum score;
			TState sgn;
			g_rim[handle]->decode(ind,score,sgn);
			plhs[0] = mxCreateDoubleScalar((double)score*sgn);
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}
 
	} else if(strcmp("order", strbuf)==0) {

		if(nrhs==2) {
			TNum handle = get_handle(nrhs,prhs);
			TNum dims = g_rim[handle]->order();
			plhs[0] = mxCreateDoubleScalar(dims);
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("statesize", strbuf)==0) {

		if(nrhs==3) {
			TNum handle = get_handle(nrhs,prhs);
			TNum dim = mxGetScalar(prhs[2]) - 1; // Matlab index start at 1
			TNum ord = g_rim[handle]->order();
			if(dim < (ord>1?ord:ord+1)) {
				TNum size = g_rim[handle]->stateSize(dim);
				plhs[0] = mxCreateDoubleScalar(size);
			} else {
				mexErrMsgTxt("Invalid dimension specified");
			}			
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("indcount", strbuf)==0) {

		if(nrhs==3) {
			TNum handle = get_handle(nrhs,prhs);
			TNum dim = mxGetScalar(prhs[2]) - 1; // Matlab index start at 1
			if(dim < g_rim[handle]->order()) {
				TNum count = g_rim[handle]->indexCount(dim);
				plhs[0] = mxCreateDoubleScalar(count);
			} else {
				mexErrMsgTxt("Invalid dimension specified");
			}			
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("indsize", strbuf)==0) {

		if(nrhs==3) {
			TNum handle = get_handle(nrhs,prhs);
			TNum dim = mxGetScalar(prhs[2]) - 1; // Matlab index start at 1
			if(dim < g_rim[handle]->order()) {
				TNum size = g_rim[handle]->indexSize(dim);
				plhs[0] = mxCreateDoubleScalar(size);
			} else {
				mexErrMsgTxt("Invalid dimension specified");
			}			
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("saturation", strbuf)==0) {

		if(nrhs==2) {
			TNum handle = get_handle(nrhs,prhs);
			TNum sat = g_rim[handle]->saturation();
			plhs[0] = mxCreateDoubleScalar(sat);
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("find", strbuf)==0) {

		if(nlhs!=4)
			mexErrMsgTxt("Expected four return variables");

		if(nrhs==5) {

			TNum i;
			TNum handle = get_handle(nrhs,prhs);
			TNum dim = g_rim[handle]->order();
			TNum N = dim>1 ? dim : dim+1; // 1D special case
			if(mxGetM(prhs[2])!=1 || mxGetN(prhs[2])!=N-1)
				mexErrMsgTxt("Invalid size of dimension array");
			if(mxGetM(prhs[3])!=1 || mxGetN(prhs[3])!=N-1)
				mexErrMsgTxt("Invalid size of index array");
			if(dim==1 && mxGetScalar(prhs[2])!=2)
				mexErrMsgTxt("You can only search for row indeces in 1D matrices, the explicit column index should be given");
			TState count = (TNum)mxGetScalar(prhs[4]);
			TNum *dims = new TNum[N-1];
			TNum *inds = new TNum[N-1];
			double *dp = mxGetPr(prhs[2]);
			double *ip = mxGetPr(prhs[3]);
			for(i=0; i<N-1; i++) {
				dims[i] = (TNum)dp[i]-1; // Matlab index start at 1
				inds[i] = (TNum)ip[i]-1; // Matlab index start at 1
			}
			TNum *p_result = new TNum[count];
			TNum *p_score = new TNum[count];
			TNum *n_result = new TNum[count];
			TNum *n_score = new TNum[count];
			g_rim[handle]->find(dims,inds,p_result,p_score,n_result,n_score,count);

			// Assemble result in matlab format
			mwSize rdims[] = {1,count};
			plhs[0] = mxCreateNumericArray(2, rdims, mxDOUBLE_CLASS, mxREAL);
			plhs[1] = mxCreateNumericArray(2, rdims, mxDOUBLE_CLASS, mxREAL);
			plhs[2] = mxCreateNumericArray(2, rdims, mxDOUBLE_CLASS, mxREAL);
			plhs[3] = mxCreateNumericArray(2, rdims, mxDOUBLE_CLASS, mxREAL);
			double *p_rr = mxGetPr(plhs[0]);
			double *p_rs = mxGetPr(plhs[1]);
			double *n_rr = mxGetPr(plhs[2]);
			double *n_rs = mxGetPr(plhs[3]);
			for(i=0; i<count; i++) {
				p_rr[i] = p_result[i] + 1; // Matlab index start at 1
				p_rs[i] = p_score[i];
				n_rr[i] = n_result[i] + 1; // Matlab index start at 1
				n_rs[i] = n_score[i];
			}
			
			delete[] dims;
			delete[] inds;
			delete[] p_result;
			delete[] p_score;
			delete[] n_result;
			delete[] n_score;
			
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("indadd", strbuf)==0) {

		if(nrhs==4) {
			TNum handle = get_handle(nrhs,prhs);
			TNum dim = mxGetScalar(prhs[2]) - 1; // Matlab index start at 1
			TNum count = mxGetScalar(prhs[3]);
			if(dim < g_rim[handle]->order()) {
				g_rim[handle]->addIndeces(dim, count);
			} else {
				mexErrMsgTxt("Invalid dimension specified");
			}			
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}
		
	} else if(strcmp("create", strbuf)==0) {

		if(nrhs==3) {
			TNum i;
			TNum dim = mxGetN(prhs[2]);
			bool argsok = dim > 0;
			argsok &= mxGetM(prhs[1])==1 && mxGetM(prhs[2])==1;
			argsok &= (dim==mxGetN(prhs[1]) || (dim==1 && mxGetN(prhs[1])==2)); 
			if(!argsok)
				mexErrMsgTxt("Invalid/inconsistent size of arguments");
			double *s = mxGetPr(prhs[1]);
			double *k = mxGetPr(prhs[2]);
			TNum *size = new TNum[(dim>1)?dim:dim+1]; // 1D special case
			TNum *inds = new TNum[dim];
			for(i=0; i<dim; i++) {
				size[i] = (TNum)s[i];
				inds[i] = (TNum)k[i];
			}
			if(dim==1) { // 1D special case
				size[1] = (TNum)s[1];
			}
			allocate(); // Allocate space
			g_rim[g_handle] = new RIMatlab(size,inds,dim);
			plhs[0] = mxCreateDoubleScalar(g_handle);
			g_handle++;

		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("randomize", strbuf)==0) {

		if(nrhs==4) {
			TNum handle = get_handle(nrhs,prhs);
			TState weight = mxGetScalar(prhs[2]);
			TNum count = mxGetScalar(prhs[3]);
			g_rim[handle]->randomize(weight, count);
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("randinit", strbuf)==0) {

		if(nrhs==4) {
			TNum handle = get_handle(nrhs,prhs);
			TState low = mxGetScalar(prhs[2]);
			TState high = mxGetScalar(prhs[3]);
			g_rim[handle]->randinit(low, high);
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("ritable", strbuf)==0) {

		if(nrhs==3) {
			TNum handle = get_handle(nrhs,prhs);
			TNum dim = mxGetScalar(prhs[2])-1; // Matlab index start at 1
			plhs[0] = g_rim[handle]->ri(dim);
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("state", strbuf)==0) {

		if(nrhs==2) {
			TNum handle = get_handle(nrhs,prhs);
			plhs[0] = g_rim[handle]->state();
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("save", strbuf)==0) {

		if(nrhs==3) {
			TNum handle = get_handle(nrhs,prhs);
			if(mxGetString(prhs[2], strbuf, sizeof(strbuf)/sizeof(char))!=0)
				mexErrMsgTxt("Expected third argument to be a file name (string)");
			std::ofstream out(strbuf, std::ios::binary);
			if(out.is_open()) {
				g_rim[handle]->write(out);
			} else {
				mexErrMsgTxt("Unable to open output file");
			}
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("load", strbuf)==0) {

		if(nrhs==2) {
			if(mxGetString(prhs[1], strbuf, sizeof(strbuf)/sizeof(char))!=0)
				mexErrMsgTxt("Expected second argument to be a file name (string)");
			std::ifstream in(strbuf, std::ios::binary);
			if(in.is_open()) {
				allocate(); // Allocate space
				g_rim[g_handle] = new RIMatlab(in);
				plhs[0] = mxCreateDoubleScalar(g_handle);
				g_handle++;
			} else {
				mexErrMsgTxt("Unable to open input file");
			}
		} else {
			mexErrMsgTxt("Invalid number of arguments");
		}

	} else if(strcmp("clear", strbuf)==0) {

		if(nrhs==2) { // Clear specific matrix
			TNum handle = get_handle(nrhs,prhs);
			delete g_rim[handle];
			g_rim[handle]=0;
		} else { // Clear all
			reset();
		}

	} else {
		mexErrMsgTxt("Unknown command");
	}
}

// EOF
