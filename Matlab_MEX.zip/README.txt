This is the first/original implementation of the N-way random indexing algorithm
with working name RITensor, which was used for the calculations presented in the
arxiv manuscript and the corresponding published paper on multidimensional RI.

The core algorithm is implemented as a C++ template with a Matlab MEX interface.

The figures presented in the paper were calculated in Matlab using this code.